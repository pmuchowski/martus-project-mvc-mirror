/*
  *
  *  *  Copyright 2014 Orient Technologies LTD (info(at)orientechnologies.com)
  *  *
  *  *  Licensed under the Apache License, Version 2.0 (the "License");
  *  *  you may not use this file except in compliance with the License.
  *  *  You may obtain a copy of the License at
  *  *
  *  *       http://www.apache.org/licenses/LICENSE-2.0
  *  *
  *  *  Unless required by applicable law or agreed to in writing, software
  *  *  distributed under the License is distributed on an "AS IS" BASIS,
  *  *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  *  *  See the License for the specific language governing permissions and
  *  *  limitations under the License.
  *  *
  *  * For more information: http://www.orientechnologies.com
  *
  */

package com.orientechnologies.common.thread;

public abstract class OPollerThread extends OSoftThread {
	protected final long	delay;

	public OPollerThread(final long iDelay) {
		delay = iDelay;
	}

	public OPollerThread(long iDelay, final ThreadGroup iThreadGroup) {
		super(iThreadGroup, OPollerThread.class.getSimpleName());
		delay = iDelay;
	}

	public OPollerThread(final long iDelay, final String name) {
		super(name);
		delay = iDelay;
	}

	public OPollerThread(final long iDelay, final ThreadGroup group, final String name) {
		super(group, name);
		delay = iDelay;
	}

	@Override
	protected void afterExecution() throws InterruptedException {
		pauseCurrentThread(delay);
	}
}
